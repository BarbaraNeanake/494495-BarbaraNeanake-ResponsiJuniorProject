﻿namespace FINALCOBA
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_NamaKaryawan = new System.Windows.Forms.Label();
            this.tb_nama = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cb_departemen = new System.Windows.Forms.ComboBox();
            this.btn_Insert = new System.Windows.Forms.Button();
            this.btn_Edit = new System.Windows.Forms.Button();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.btn_Load = new System.Windows.Forms.Button();
            this.dvg_karyawan = new System.Windows.Forms.DataGridView();
            this.pb_Logo = new System.Windows.Forms.PictureBox();
            this.info_dep = new System.Windows.Forms.Label();
            this.lbl_KaryawanTerpilih = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dvg_karyawan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Logo)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_NamaKaryawan
            // 
            this.lbl_NamaKaryawan.AccessibleName = "lbl_NamaKaryawan";
            this.lbl_NamaKaryawan.AutoSize = true;
            this.lbl_NamaKaryawan.Location = new System.Drawing.Point(35, 116);
            this.lbl_NamaKaryawan.Name = "lbl_NamaKaryawan";
            this.lbl_NamaKaryawan.Size = new System.Drawing.Size(55, 20);
            this.lbl_NamaKaryawan.TabIndex = 0;
            this.lbl_NamaKaryawan.Text = "Nama:";
            // 
            // tb_nama
            // 
            this.tb_nama.AccessibleName = "tb_nama";
            this.tb_nama.Location = new System.Drawing.Point(200, 109);
            this.tb_nama.Name = "tb_nama";
            this.tb_nama.Size = new System.Drawing.Size(240, 26);
            this.tb_nama.TabIndex = 1;
            this.tb_nama.TextChanged += new System.EventHandler(this.tb_nama_TextChanged);
            // 
            // label1
            // 
            this.label1.AccessibleName = "lbl_Departemen";
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 165);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Departemen:";
            // 
            // label2
            // 
            this.label2.AccessibleName = "lbl_KaryawanTerpilih";
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 213);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 20);
            this.label2.TabIndex = 3;
            // 
            // cb_departemen
            // 
            this.cb_departemen.FormattingEnabled = true;
            this.cb_departemen.Location = new System.Drawing.Point(200, 165);
            this.cb_departemen.Name = "cb_departemen";
            this.cb_departemen.Size = new System.Drawing.Size(240, 28);
            this.cb_departemen.TabIndex = 4;
            this.cb_departemen.SelectedIndexChanged += new System.EventHandler(this.cb_departemen_SelectedIndexChanged);
            // 
            // btn_Insert
            // 
            this.btn_Insert.Location = new System.Drawing.Point(39, 261);
            this.btn_Insert.Name = "btn_Insert";
            this.btn_Insert.Size = new System.Drawing.Size(88, 30);
            this.btn_Insert.TabIndex = 5;
            this.btn_Insert.Text = "Insert";
            this.btn_Insert.UseVisualStyleBackColor = true;
            this.btn_Insert.Click += new System.EventHandler(this.btn_Insert_Click);
            // 
            // btn_Edit
            // 
            this.btn_Edit.Location = new System.Drawing.Point(200, 261);
            this.btn_Edit.Name = "btn_Edit";
            this.btn_Edit.Size = new System.Drawing.Size(88, 30);
            this.btn_Edit.TabIndex = 6;
            this.btn_Edit.Text = "Edit";
            this.btn_Edit.UseVisualStyleBackColor = true;
            this.btn_Edit.Click += new System.EventHandler(this.btn_Edit_Click);
            // 
            // btn_Delete
            // 
            this.btn_Delete.Location = new System.Drawing.Point(352, 261);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(88, 30);
            this.btn_Delete.TabIndex = 7;
            this.btn_Delete.Text = "Delete";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // btn_Load
            // 
            this.btn_Load.Location = new System.Drawing.Point(510, 261);
            this.btn_Load.Name = "btn_Load";
            this.btn_Load.Size = new System.Drawing.Size(88, 30);
            this.btn_Load.TabIndex = 8;
            this.btn_Load.Text = "Load Data";
            this.btn_Load.UseVisualStyleBackColor = true;
            // 
            // dvg_karyawan
            // 
            this.dvg_karyawan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dvg_karyawan.Location = new System.Drawing.Point(39, 331);
            this.dvg_karyawan.Name = "dvg_karyawan";
            this.dvg_karyawan.RowHeadersWidth = 62;
            this.dvg_karyawan.RowTemplate.Height = 28;
            this.dvg_karyawan.Size = new System.Drawing.Size(710, 150);
            this.dvg_karyawan.TabIndex = 9;
            this.dvg_karyawan.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dvg_karyawan_CellContentClick);
            // 
            // pb_Logo
            // 
            this.pb_Logo.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pb_Logo.Location = new System.Drawing.Point(39, 24);
            this.pb_Logo.Name = "pb_Logo";
            this.pb_Logo.Size = new System.Drawing.Size(148, 61);
            this.pb_Logo.TabIndex = 10;
            this.pb_Logo.TabStop = false;
            // 
            // info_dep
            // 
            this.info_dep.AccessibleName = "lbl_Departemen";
            this.info_dep.AutoSize = true;
            this.info_dep.Location = new System.Drawing.Point(506, 74);
            this.info_dep.Name = "info_dep";
            this.info_dep.Size = new System.Drawing.Size(200, 120);
            this.info_dep.TabIndex = 11;
            this.info_dep.Text = "INFO INFO\r\n(\'HR\', \'Human Resources\'),\r\n(\'ENG\', \'Engineer\'),\r\n(\'DEV\', \'Developer\')" +
    ",\r\n(\'PM\', \'Product Manager\'),\r\n(\'FIN\', \'Finance\');";
            // 
            // lbl_KaryawanTerpilih
            // 
            this.lbl_KaryawanTerpilih.AccessibleName = "lbl_Departemen";
            this.lbl_KaryawanTerpilih.AutoSize = true;
            this.lbl_KaryawanTerpilih.Location = new System.Drawing.Point(41, 224);
            this.lbl_KaryawanTerpilih.Name = "lbl_KaryawanTerpilih";
            this.lbl_KaryawanTerpilih.Size = new System.Drawing.Size(21, 20);
            this.lbl_KaryawanTerpilih.TabIndex = 12;
            this.lbl_KaryawanTerpilih.Text = "\"\"";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 507);
            this.Controls.Add(this.lbl_KaryawanTerpilih);
            this.Controls.Add(this.info_dep);
            this.Controls.Add(this.pb_Logo);
            this.Controls.Add(this.dvg_karyawan);
            this.Controls.Add(this.btn_Load);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.btn_Edit);
            this.Controls.Add(this.btn_Insert);
            this.Controls.Add(this.cb_departemen);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_nama);
            this.Controls.Add(this.lbl_NamaKaryawan);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dvg_karyawan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Logo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_NamaKaryawan;
        private System.Windows.Forms.TextBox tb_nama;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cb_departemen;
        private System.Windows.Forms.Button btn_Insert;
        private System.Windows.Forms.Button btn_Edit;
        private System.Windows.Forms.Button btn_Delete;
        private System.Windows.Forms.Button btn_Load;
        private System.Windows.Forms.DataGridView dvg_karyawan;
        private System.Windows.Forms.PictureBox pb_Logo;
        private System.Windows.Forms.Label info_dep;
        private System.Windows.Forms.Label lbl_KaryawanTerpilih;
    }
}

